// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MSG_CLASE__MSG__SPHERE_HPP_
#define MSG_CLASE__MSG__SPHERE_HPP_

#include "msg_clase/msg/detail/sphere__struct.hpp"
#include "msg_clase/msg/detail/sphere__builder.hpp"
#include "msg_clase/msg/detail/sphere__traits.hpp"

#endif  // MSG_CLASE__MSG__SPHERE_HPP_
