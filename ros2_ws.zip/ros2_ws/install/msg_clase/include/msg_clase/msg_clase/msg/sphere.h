// generated from rosidl_generator_c/resource/idl.h.em
// with input from msg_clase:msg/Sphere.idl
// generated code does not contain a copyright notice

#ifndef MSG_CLASE__MSG__SPHERE_H_
#define MSG_CLASE__MSG__SPHERE_H_

#include "msg_clase/msg/detail/sphere__struct.h"
#include "msg_clase/msg/detail/sphere__functions.h"
#include "msg_clase/msg/detail/sphere__type_support.h"

#endif  // MSG_CLASE__MSG__SPHERE_H_
