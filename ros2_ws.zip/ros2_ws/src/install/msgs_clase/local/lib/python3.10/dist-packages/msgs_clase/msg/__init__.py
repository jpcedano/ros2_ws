from msgs_clase.msg._sphere import Sphere  # noqa: F401
