// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef MSGS_CLASE__MSG__SPHERE_HPP_
#define MSGS_CLASE__MSG__SPHERE_HPP_

#include "msgs_clase/msg/detail/sphere__struct.hpp"
#include "msgs_clase/msg/detail/sphere__builder.hpp"
#include "msgs_clase/msg/detail/sphere__traits.hpp"

#endif  // MSGS_CLASE__MSG__SPHERE_HPP_
