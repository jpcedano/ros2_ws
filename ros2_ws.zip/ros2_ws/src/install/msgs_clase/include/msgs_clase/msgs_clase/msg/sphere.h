// generated from rosidl_generator_c/resource/idl.h.em
// with input from msgs_clase:msg/Sphere.idl
// generated code does not contain a copyright notice

#ifndef MSGS_CLASE__MSG__SPHERE_H_
#define MSGS_CLASE__MSG__SPHERE_H_

#include "msgs_clase/msg/detail/sphere__struct.h"
#include "msgs_clase/msg/detail/sphere__functions.h"
#include "msgs_clase/msg/detail/sphere__type_support.h"

#endif  // MSGS_CLASE__MSG__SPHERE_H_
