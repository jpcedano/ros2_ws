// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from signal_msg:msg/SignalDecomposed.idl
// generated code does not contain a copyright notice
#ifndef SIGNAL_MSG__MSG__DETAIL__SIGNAL_DECOMPOSED__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define SIGNAL_MSG__MSG__DETAIL__SIGNAL_DECOMPOSED__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "signal_msg/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_signal_msg
size_t get_serialized_size_signal_msg__msg__SignalDecomposed(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_signal_msg
size_t max_serialized_size_signal_msg__msg__SignalDecomposed(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_signal_msg
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, signal_msg, msg, SignalDecomposed)();

#ifdef __cplusplus
}
#endif

#endif  // SIGNAL_MSG__MSG__DETAIL__SIGNAL_DECOMPOSED__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
