// generated from rosidl_generator_c/resource/idl.h.em
// with input from signal_msg:msg/SignalDecomposed.idl
// generated code does not contain a copyright notice

#ifndef SIGNAL_MSG__MSG__SIGNAL_DECOMPOSED_H_
#define SIGNAL_MSG__MSG__SIGNAL_DECOMPOSED_H_

#include "signal_msg/msg/detail/signal_decomposed__struct.h"
#include "signal_msg/msg/detail/signal_decomposed__functions.h"
#include "signal_msg/msg/detail/signal_decomposed__type_support.h"

#endif  // SIGNAL_MSG__MSG__SIGNAL_DECOMPOSED_H_
